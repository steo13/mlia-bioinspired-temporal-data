#!/bin/bash
export NNI_PLATFORM='local'
export NNI_EXP_ID='hE7GnMeb'
export NNI_SYS_DIR='/root/nni-experiments/hE7GnMeb/trials/qF0KU'
export NNI_TRIAL_JOB_ID='qF0KU'
export NNI_OUTPUT_DIR='/root/nni-experiments/hE7GnMeb/trials/qF0KU'
export NNI_TRIAL_SEQ_ID='4'
export NNI_CODE_DIR='/content/NNI/experiments'
export CUDA_VISIBLE_DEVICES='0'
cd $NNI_CODE_DIR
eval python nni_slmu_original.py 2>"/root/nni-experiments/hE7GnMeb/trials/qF0KU/stderr"
echo $? `date +%s%3N` >'/root/nni-experiments/hE7GnMeb/trials/qF0KU/.nni/state'
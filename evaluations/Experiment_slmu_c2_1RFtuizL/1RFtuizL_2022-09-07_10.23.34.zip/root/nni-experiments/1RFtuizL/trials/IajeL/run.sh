#!/bin/bash
export NNI_PLATFORM='local'
export NNI_EXP_ID='1RFtuizL'
export NNI_SYS_DIR='/root/nni-experiments/1RFtuizL/trials/IajeL'
export NNI_TRIAL_JOB_ID='IajeL'
export NNI_OUTPUT_DIR='/root/nni-experiments/1RFtuizL/trials/IajeL'
export NNI_TRIAL_SEQ_ID='30'
export NNI_CODE_DIR='/content/NNI/experiments'
export CUDA_VISIBLE_DEVICES='0'
cd $NNI_CODE_DIR
eval python nni_slmu.py 2>"/root/nni-experiments/1RFtuizL/trials/IajeL/stderr"
echo $? `date +%s%3N` >'/root/nni-experiments/1RFtuizL/trials/IajeL/.nni/state'
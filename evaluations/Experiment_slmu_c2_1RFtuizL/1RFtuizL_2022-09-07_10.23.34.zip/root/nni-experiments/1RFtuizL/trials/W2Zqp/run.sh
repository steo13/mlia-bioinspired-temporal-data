#!/bin/bash
export NNI_PLATFORM='local'
export NNI_EXP_ID='1RFtuizL'
export NNI_SYS_DIR='/root/nni-experiments/1RFtuizL/trials/W2Zqp'
export NNI_TRIAL_JOB_ID='W2Zqp'
export NNI_OUTPUT_DIR='/root/nni-experiments/1RFtuizL/trials/W2Zqp'
export NNI_TRIAL_SEQ_ID='26'
export NNI_CODE_DIR='/content/NNI/experiments'
export CUDA_VISIBLE_DEVICES='0'
cd $NNI_CODE_DIR
eval python nni_slmu.py 2>"/root/nni-experiments/1RFtuizL/trials/W2Zqp/stderr"
echo $? `date +%s%3N` >'/root/nni-experiments/1RFtuizL/trials/W2Zqp/.nni/state'
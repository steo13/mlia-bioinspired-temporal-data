#!/bin/bash
export NNI_PLATFORM='local'
export NNI_EXP_ID='KCzsw1MN'
export NNI_SYS_DIR='/root/nni-experiments/KCzsw1MN/trials/txNp7'
export NNI_TRIAL_JOB_ID='txNp7'
export NNI_OUTPUT_DIR='/root/nni-experiments/KCzsw1MN/trials/txNp7'
export NNI_TRIAL_SEQ_ID='61'
export NNI_CODE_DIR='/content/NNI/experiments'
export CUDA_VISIBLE_DEVICES='0'
cd $NNI_CODE_DIR
eval python nni_slmu.py 2>"/root/nni-experiments/KCzsw1MN/trials/txNp7/stderr"
echo $? `date +%s%3N` >'/root/nni-experiments/KCzsw1MN/trials/txNp7/.nni/state'
#!/bin/bash
export NNI_PLATFORM='local'
export NNI_EXP_ID='EnCi34wL'
export NNI_SYS_DIR='/root/nni-experiments/EnCi34wL/trials/pc3KA'
export NNI_TRIAL_JOB_ID='pc3KA'
export NNI_OUTPUT_DIR='/root/nni-experiments/EnCi34wL/trials/pc3KA'
export NNI_TRIAL_SEQ_ID='3'
export NNI_CODE_DIR='/content/NNI/experiments'
export CUDA_VISIBLE_DEVICES='0'
cd $NNI_CODE_DIR
eval python nni_slmu.py 2>"/root/nni-experiments/EnCi34wL/trials/pc3KA/stderr"
echo $? `date +%s%3N` >'/root/nni-experiments/EnCi34wL/trials/pc3KA/.nni/state'